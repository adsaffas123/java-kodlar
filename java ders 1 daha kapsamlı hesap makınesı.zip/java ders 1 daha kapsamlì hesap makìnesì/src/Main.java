import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        Scanner scan =new Scanner(System.in);

        System.out.print("""

        HESAP MAKINESI

      TOPLAMA ISLEMI ICIN 1'E BASIN.
      CIKARMA ISLEMI ICIN 2'E BASIN.
      BOLME ISLEMI ICIN 3'E BASIN.
      CARPMA ISLEMI ICIN 4'E BASIN.

      """);

        int secim=scan.nextInt();

        if(secim == 1) {
            System.out.print("1.sayıyı giriniz: ");

            int sayi1 = scan.nextInt();

            System.out.println("2.sayıyı giriniz: ");

            int sayi2 = scan.nextInt();

            System.out.println("toplama isleminin sonucu = " + (sayi1 - sayi2));

        }


        else if(secim ==2)   {

            System.out.print("1.sayıyı giriniz: ");

            int sayi1 = scan.nextInt();

            System.out.println("2.sayıyı giriniz: ");

            int sayi2 = scan.nextInt();

            if (secim == 1)

                System.out.println("cıkarma islemi sonucu = " + (sayi1 - sayi2));
        }


        else if(secim ==3) {

            System.out.println("1.sayıyı giriniz: ");

            int sayi1 = scan.nextInt();

            System.out.println("2.sayıyı giritniz: ");

            int sayi2 = scan.nextInt();

            System.out.println("bolme isleminin sonucu = " + (sayi1 / sayi2));

        }

            else if(secim ==4)
        {
            System.out.println("1.sayıyı giriniz: ");

            int sayi1 = scan.nextInt();

            System.out.println("2.sayıyı giriniz: ");

            int sayi2 = scan.nextInt();

            System.out.println("Carpma isleminin sonucu = " + (sayi1 * sayi2));

        }


          else
            System.out.print("yanlıs secim yaptınız,yeniden deneyiniz. ");












        }


    }
