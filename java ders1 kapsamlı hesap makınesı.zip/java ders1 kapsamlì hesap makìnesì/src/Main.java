import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scan =new Scanner(System.in);


                System.out.print("1. sayıyı giriniz: ");

                    int sayi1 = scan.nextInt();

                System.out.print("2.sayıyı giriniz: ");

                    int sayi2 = scan.nextInt();

                    System.out.println("****İşleminizi seçiniz****");

                        System.out.println("1.Toplama");
                        System.out.println("2.cıkarma");
                        System.out.println("3.bolme");
                        System.out.println("4.carpma");

                    System.out.println("****Seciminizi giriniz****");

                        int secim = scan.nextInt();

                        if(secim  == 1)
                        System.out.printf("Toplama islemi sonucu= " + (sayi1 + sayi2));

                     else if(secim  == 2)

                        System.out.print("cıkarma islemi sonucu= " + (sayi1 - sayi2));

                    else if(secim  == 3)

                        System.out.printf("Bolme islemi sonucu= " + (float)(sayi1 / sayi2));

                    else if(secim  == 4)

                            System.out.println("Carpma islemi sonucu= " + (sayi1 * sayi2));

                    else
                        System.out.println("Yanlıs secim yaptınız.Secımiminizi kontrol ediniz. ");












        }









    }
