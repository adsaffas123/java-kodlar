import java.util.Scanner;

import static java.lang.System.out;

public class Main {
    public static void main(String[] args) {

            Scanner input=new Scanner(System.in);

            int number1;
            int number2;
            int number3;

            System.out.print("Enter the first number: ");

                number1 =input.nextInt();

            System.out.print("Enter the second number: ");

                number2 =input.nextInt();

            System.out.print("Enter the third number: ");

                number3 =input.nextInt();

                System.out.printf("the product is %d", number1*number2*number3);



    }

}